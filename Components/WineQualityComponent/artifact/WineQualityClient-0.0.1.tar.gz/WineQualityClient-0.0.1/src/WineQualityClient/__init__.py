__author__ = "lalitdutt parsai"

from WineQualityClient.Client import Client